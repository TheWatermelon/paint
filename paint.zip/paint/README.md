# Paint

## Introduction

Projet de paint en Java dans le cadre de l'IFT 232 (Conception Orientée Objet).
