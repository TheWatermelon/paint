Fichier de conversation

TODO:
 - Version zéro du projet depuis JFig
 
 
GIT
 La branche master n'est utilisée que pour les 'releases'
