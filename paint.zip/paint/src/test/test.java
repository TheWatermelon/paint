package test;


public class test {

	
	int a;
	int b;
	int c;
	int d;
	
	public static void main(String[] args) {
		System.out.println("Hello world!");
	}
	
}
