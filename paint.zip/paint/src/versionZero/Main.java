package versionZero;

import versionZero.vue.Fenetre;

public class Main {
	public static void main(String[] args) {
		Fenetre f = new Fenetre("BasicPaint");
		f.setVisible(true);
	}
}
