package vue;

public interface observer {
	
	
	public abstract void update();
	

}
