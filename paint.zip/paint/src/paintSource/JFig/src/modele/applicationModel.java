package modele;

public class applicationModel extends observable{
	
	
	
	
	

}
