/**
 * 
 */
/**
 * @author florent
 *
 */
package ca.uds.jfig.application;