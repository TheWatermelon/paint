/**
 * 
 */
/**
 * @author florent
 *
 */
package ca.uds.jfig.jfigInterface;