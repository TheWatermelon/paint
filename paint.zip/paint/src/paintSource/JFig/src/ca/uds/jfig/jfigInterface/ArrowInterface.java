/**
 * @author Nolwenn ROGER 
 * 
 */

package ca.uds.jfig.jfigInterface;

public interface ArrowInterface {
	final int ARROW = 20;
	final String ARROW_STR = "arrow";
	final int ARROWDOUBLE = 21;
	final String ARROWDOUBLE_STR = "arrowDouble";
	final int ARROWFILL = 22;
	final String ARROWFILL_STR = "arrowFill";
	final int ARROWFILLDOUBLE = 23;
	final String ARROWFILLDOUBLE_STR = "arrowFillDouble";
}
