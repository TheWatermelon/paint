/**
 * 
 */

/**
 * @author Coatanea Brendan
 * @date 29/04/2013
 *
 */
package ca.uds.jfig.menu;

public interface Command {
	
	public void execute();
	
}