/**
 * 
 */
/**
 * @author florent
 *
 */
package ca.uds.jfig.figureView;