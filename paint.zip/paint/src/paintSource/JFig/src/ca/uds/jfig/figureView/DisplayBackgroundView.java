package ca.uds.jfig.figureView;

import java.awt.Color;

import javax.swing.JPanel;

@SuppressWarnings("serial")
public class DisplayBackgroundView extends JPanel{
	public DisplayBackgroundView(){
		this.setBackground(Color.WHITE);
	}
}
