/**
 * 
 */
/**
 * @author florent
 *
 */
package ca.uds.jfig.figures;